# Vínculo de criaturas com habitats v1.0c

Substitua os oito scripts de mesmo nome e adicione `CreatureHabitatLink.cs`.
O `RequireComponent` do `CreatureController` adiciona o novo componente ao
prefab automaticamente quando o script é carregado; confirme sua presença no
prefab da criatura antes de salvar o projeto.

## Configuração

O asset `CreatureHabitatSettingsSO` agora possui:

- `Arrival Distance`: comece com `1`;
- `Path Retry Delay`: `2` segundos;
- `Path Attempts Before Relocation`: `3`;
- `Allow Emergency Relocation`: habilitado durante esta fase.

Não altere o `CreatureDefinitionSO` para configurar o habitat. A espécie
compatível continua sendo definida no asset do próprio habitat.

## Fluxo esperado

1. Uma criatura domesticada encontra o habitat compatível mais próximo.
2. A vaga é reservada imediatamente, evitando duas criaturas na mesma vaga.
3. Ela caminha até uma célula navegável do território.
4. Se o A* falhar, espera o intervalo configurado e tenta novamente.
5. Após três falhas, usa relocação emergencial para uma célula navegável.
6. Ao chegar, `HomePosition` passa a ser o centro de patrulha do habitat.
7. O vínculo e a posição da construção são gravados no save.

Perigo continua tendo prioridade sobre a viagem ao habitat. Ao desmontar o
habitat, a criatura percebe o vínculo inválido e procura outro disponível.

## Testes mínimos

1. Habitat acessível: domestique e confirme a caminhada normal.
2. Capacidade 1: use duas criaturas e confirme que apenas uma reserva a vaga.
3. Caminho bloqueado: confirme três falhas e a relocação emergencial.
4. Desmonte o habitat e confirme que a criatura volta para `Unbound`.
5. Salve e carregue com a criatura vinculada; confirme o mesmo habitat no F2.
6. Confirme no F2: estado, nome do habitat, tentativas e último resultado.

Se a criatura se teleportar em um teste que deveria possuir caminho, copie a
linha `[CreatureHabitat]` e a `Última falha` do F2 antes de modificar o mapa.
