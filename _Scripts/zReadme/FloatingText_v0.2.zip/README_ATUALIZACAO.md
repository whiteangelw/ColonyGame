# Floating Text v0.2

Substitua apenas o seu `FloatingText.cs` por este arquivo. Nenhum outro
script precisa ser alterado.

No prefab **FloatingText**, configure no Inspector:

- `Use Typewriter Effect`: liga/desliga a revelação letra por letra;
- `Characters Per Second`: velocidade da digitação. Sugestão: `30` a `40`;
- `Minimum Visible Duration`: tempo mínimo após a frase terminar. Sugestão:
  `1.25` a `1.75`;
- `Visible Seconds Per Character`: tempo extra para frases longas. Sugestão:
  `0.02` a `0.04`;
- `Fade Duration`: duração do desaparecimento. Sugestão: `0.35` a `0.55`;
- `Move Speed`: velocidade vertical. Sugestão: `0.3` a `0.6`.

Exemplo: a frase `"Vou procurar algo para comer."` possui mais caracteres e
por isso recebe alguns décimos de segundo extras para leitura.

O efeito vale para todos os textos enviados ao `FloatingTextManager`, inclusive
ganhos de recursos. Se quiser o comportamento antigo, desmarque
`Use Typewriter Effect`; a permanência legível continua funcionando.
