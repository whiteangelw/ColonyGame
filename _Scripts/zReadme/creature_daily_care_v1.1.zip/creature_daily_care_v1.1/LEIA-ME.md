# Cuidado diário por ciclo v1.1

Substitua os cinco scripts incluídos. Não altere prefabs.

## Configuração do CreatureTamingProfileSO

Para o primeiro teste:

- `Minimum Feedings Per Cycle = 1`;
- `Healthy Feedings Per Cycle = 2`;
- `Tolerated Extra Feedings = 1`;
- `Overfeeding Progress Penalty = 3`;
- `Neglect Penalty Per Missing Feeding = 3`.

Com essa configuração, a primeira e a segunda alimentações são saudáveis. A
terceira ainda é aceita, causa penalidade e inicia recusa até o próximo ciclo.
Novas tentativas não devem gerar tarefa de entrega.

Somente alimentação direta conta. Alimentos consumidos do chão continuam
ligados apenas à fome/satisfação da criatura.

## Virada do ciclo

Ao iniciar um novo dia, `DayNightCycleManager` dispara `OnDayStarted` uma única
vez. Cada criatura avalia o ciclo encerrado, aplica negligência por alimentação
mínima ausente e zera o contador e a recusa diária.

O primeiro ciclo após a migração de um save antigo possui tolerância: carregar
um save não cria penalidade retroativa.

## Testes

1. Alimente duas vezes e avance o dia: nenhuma penalidade.
2. Passe um dia sem alimentar após já ter iniciado o cuidado: perde 3 pontos.
3. Alimente três vezes: a terceira causa excesso e ativa recusa.
4. Tente uma quarta vez: a criatura não deve aceitar a solicitação.
5. Avance o dia: a recusa termina e o contador volta a zero.
6. Salve no meio do dia e carregue: dia e quantidade permanecem iguais.
7. Confira no F2 o ciclo, quantidade, mínimo, máximo e último ciclo.

`IsDailyCareSatisfiedForBenefits` já fica disponível para a futura habilidade
Jardineira Territorial. No primeiro ciclo domesticado, ela recebe tolerância;
depois, o valor depende do último ciclo completo.
