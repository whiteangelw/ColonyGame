# Correção de clique no baú — v1.0

Substitua somente `BoxSelectionHandler.cs` pela versão da pasta `Scripts`.

## O que mudou

- O clique no baú é resolvido primeiro pelos limites visuais dos seus Renderers.
- Colliders continuam sendo usados como fallback para outras interações.
- O registro do grid continua sendo usado como fallback determinístico.
- Nenhuma regra de inventário, save, construção ou desmontagem foi alterada.

## Teste

1. Saia do Play Mode.
2. Substitua o script e espere a compilação.
3. Carregue o mundo sem mover o baú manualmente.
4. Clique no centro e nas bordas do sprite.
5. Feche e reabra a UI.
6. Construa um baú novo e repita.

O Transform do baú não deve ser movido manualmente: sua posição é controlada
pelo grid. O teste com o objeto deslocado serviu somente para revelar a diferença
entre a posição visual e a célula registrada.
