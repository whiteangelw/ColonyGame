# Jardinagem territorial e diagnóstico — v1.3b

Substitua:

- `CreatureDomestication.cs`
- `CreatureTerritorialGardener.cs`
- `CreatureGardeningRegistry.cs`
- `CreatureDebugPanel.cs`

Não altere a plantadeira nem os prefabs.

## Regra da habilidade

A criatura precisa estar domesticada, com cuidado válido, habilidade de
jardinagem configurada e habitat vinculado. O habitat confirma o vínculo, mas
não cria um segundo raio invisível.

Todas as plantadeiras crescendo dentro do `Interaction Radius` circular da
criatura recebem o bônus. Plantadeiras prontas, vazias ou aguardando materiais
não recebem progresso. Duas criaturas não acumulam o bônus na mesma
plantadeira; somente a fornecedora de maior bônus é usada.

## Diagnóstico F2

O painel passa a mostrar:

- plantadeiras registradas, crescendo, no alcance e afetadas;
- alcance circular e distância da plantadeira crescente mais próxima;
- motivo específico quando nenhuma plantadeira recebe o bônus;
- dia atual, ciclo acompanhado e ciclo da última alimentação direta;
- mínimo de cuidado, limite saudável e máximo aceito separadamente.

Comida ingerida diretamente do chão continua não contando para domesticação.
Somente a entrega direta solicitada registra alimentação no ciclo.
