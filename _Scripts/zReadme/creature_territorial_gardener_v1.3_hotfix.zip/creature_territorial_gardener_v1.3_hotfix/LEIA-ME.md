# Hotfix — Jardineira Territorial v1.3

Substitua apenas `CreatureGardeningRegistry.cs` pelo arquivo desta pasta.

## Correção

Versões recentes do Unity descontinuaram `Object.GetInstanceID()`. O método era
usado somente para desempatar duas criaturas com o mesmo bônus. Como ambos os
bônus têm o mesmo valor, a escolha de qualquer uma delas produz o mesmo efeito;
o registro continua permitindo somente um pulso por plantadeira.
