# Alertas de atenção dos personagens — v1.0

Esta versão adiciona um alerta global clicável sem modificar os scripts atuais
de necessidades, câmera, ciclo de vida ou seleção.

## O que acontece

- o botão aparece somente quando existe um problema configurado;
- o contador informa quantos personagens estão afetados;
- o primeiro clique focaliza o caso mais grave;
- os cliques seguintes percorrem os demais casos;
- o personagem focalizado também é selecionado;
- problemas resolvidos saem automaticamente da lista;
- depois do último personagem, o ciclo volta ao primeiro.

Por padrão, apenas `Desmaiado`, `Fome crítica` e `Energia crítica` geram
alertas. Isso evita excesso de notificações.

## 1. Serviço central

No `GameManager`, crie um filho chamado `DuplicantAttentionService` e adicione:

- `DuplicantAttentionService`.

Deixe esse objeto sempre ativo.

## 2. Prefab do personagem

No objeto raiz do prefab que já contém `DuplicantVitals` e
`DuplicantSelectionTarget`, adicione:

- `DuplicantAttentionSource`.

Deixe `Include Hungry` e `Include Tired` desmarcados inicialmente. Essas opções
permitem alertas preventivos, mas podem poluir a interface.

## 3. Interface

Dentro do Canvas, crie esta estrutura sugerida:

```text
AttentionAlert
└── AlertButton
    ├── Icon
    ├── CountText (TMP)
    └── ReasonText (TMP)  [opcional]
```

No objeto `AttentionAlert`, adicione `DuplicantAttentionUI` e atribua:

- `Alert Root`: `AttentionAlert`;
- `Alert Button`: o botão;
- `Count Text`: texto numérico;
- `Reason Text`: texto da causa mais grave, opcional;
- `Camera Controller`: objeto que contém `CameraController`.

Não desative manualmente o objeto que contém `DuplicantAttentionUI`. O script
precisa continuar ativo para reabrir o alerta. Ele esconde somente o botão ou
um `Alert Root` filho.

### Configuração visual sugerida

- ancoragem: canto superior direito;
- tamanho do botão: `64 x 64`;
- `Icon`: símbolo de atenção;
- `CountText`: pequeno círculo com número;
- `ReasonText`: pode ficar abaixo do botão ou ser omitido;
- todos os elementos decorativos devem ter `Raycast Target` desmarcado;
- mantenha `Raycast Target` apenas na imagem do `Button`.

## Teste rápido

1. Entre no Play Mode sem necessidades críticas: o alerta fica oculto.
2. Use o Inspector/DevMode para colocar fome abaixo do limite crítico.
3. Confirme que o alerta aparece e mostra `1`.
4. Clique: a câmera deve focalizar e selecionar o personagem.
5. Deixe dois personagens críticos e clique repetidamente.
6. Restaure as necessidades: o alerta deve desaparecer.

## Observação arquitetural

O sistema é orientado pelos eventos de `DuplicantVitals`, portanto não procura
todos os personagens a cada frame. A UI cuida apenas da apresentação; a lista e
a prioridade ficam no serviço; cada personagem apenas relata seu próprio
estado.
