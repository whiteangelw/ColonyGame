# Recuperação do cuidado diário — v1.3a

Substitua estes dois scripts:

- `CreatureDomestication.cs`
- `CreatureDebugPanel.cs`

Não é necessário alterar a plantadeira nem os componentes dos prefabs.

## Regra corrigida

- Se o último ciclo foi bem cuidado, o benefício permanece ativo.
- Se o último ciclo foi negligenciado, o benefício fica bloqueado.
- Ao cumprir o mínimo de alimentação no ciclo atual, o benefício retorna
  imediatamente, sem esperar a próxima virada de dia.
- A penalidade do ciclo negligenciado continua preservada.
- A consulta do benefício sincroniza o dia atual como proteção adicional para
  inicialização, carregamento e eventual ausência do evento de virada.

## Diagnóstico F2

Em `DOMESTICAÇÃO (INTERNO)`, observe:

- `Cuidado atual cumprido`;
- `Último ciclo válido`;
- `Benefício de cuidado ativo`.

Em `JARDINAGEM TERRITORIAL (INTERNO)`, `Elegível agora` deve voltar para
`True` depois que o mínimo atual for cumprido, desde que a criatura esteja
domesticada, vinculada ao habitat e com a habilidade configurada.
