# P5D — Flora e recursos como entidades

O P5D adiciona flora procedural determinística em patches. A geração produz
somente dados (`GeneratedFloraData`); `FloraManager` instancia os prefabs após
o grid ficar pronto. `WorldGenerator` não conhece prefabs, cena ou entidades.

## Compatibilidade por versão

- Versão 1: pipeline legado, sem flora procedural.
- Versão 2: P5C preservado, sem flora procedural.
- Versão 3: P5D ativo.

Use `Generation Version = 3` somente depois de configurar as regras de flora.

## Arquivos para substituir

- `BiomeDefinitionSO.cs`
- `FloraDefinitionSO.cs`
- `FloraManager.cs`
- `HarvestableFoodSource.cs`
- `GridManager.cs`
- `SaveGameService.cs`
- `WorldGenerationPasses.cs`
- `WorldGenerationPassFactory.cs`
- `WorldGenerationResult.cs`
- `WorldGenerator.cs`

## Arquivo novo

- `FloraEntity.cs`

## Configuração no Unity

1. Em cada `FloraDefinitionSO`, atribua um `floraId` único e um prefab.
2. Marque `Provides Food` somente para plantas que são fontes de alimento.
3. Prefabs de alimento podem conter `HarvestableFoodSource`.
4. Prefabs não alimentares podem conter `FloraEntity`; se não contiverem, o
   `FloraManager` adiciona o componente em runtime.
5. No `FloraManager`, adicione todas as definições à lista `Definitions`. Isso
   é necessário para restaurar a flora pelo `floraId` durante o Load.
6. Abra cada `BiomeDefinitionSO` e adicione regras em `Flora`.
7. Em cada regra, atribua `Definition`, densidade, tamanho do patch,
   profundidade, limite opcional e terrenos permitidos.
8. Mude o `WorldGenerator` para `Generation Version = 3`.

`Density` representa a chance de uma célula plantável iniciar um patch. Comece
baixo, por exemplo entre `0.002` e `0.01`, especialmente em mapas 500x500.
`Maximum Instances = 0` significa sem limite; durante ajustes, prefira definir
um limite para evitar milhares de GameObjects.

## Responsabilidades

- `BiomeFloraRule`: regras de distribuição por bioma.
- `FloraPass`: encontra células válidas e gera patches determinísticos.
- `WorldGenerationResult`: armazena descritores, sem instanciar objetos.
- `GridManager`: publica que um mundo novo terminou de ser aplicado.
- `FloraManager`: instancia, registra, restaura e limpa entidades.
- `FloraEntity`: identidade e quantidade genérica da flora.
- `HarvestableFoodSource`: comportamento alimentar já existente.
- `SaveGameService`: mantém o formato atual de `FloraSaveData`.

## Testes manuais

1. Confirme que versões 1 e 2 continuam sem flora procedural.
2. Gere versão 3 duas vezes com a mesma seed e compare posições/quantidades.
3. Gere com outra seed e confirme distribuição diferente.
4. Teste 100x90, 250x250 e 500x500.
5. Verifique patches coerentes, sem duas floras na mesma célula.
6. Verifique que não nasce flora em líquido, dentro de terreno, sem suporte ou
   na área livre do spawn.
7. Salve e carregue. A quantidade e as posições devem permanecer iguais, sem
   duplicar a flora procedural durante o Load.
8. Consuma uma planta alimentar, salve e carregue; a quantidade restante deve
   ser restaurada.
9. Teste uma flora com `Provides Food` desmarcado e confirme que ela não entra
   no registro de fontes de alimento.

## Limites desta fase

- Não adiciona tarefa de coleta ou autorização do jogador.
- Não adiciona crescimento ou regeneração.
- Não implementa chunks ou culling.
- Mantém o formato atual do save; `availablePortions` continua sendo usado
  como quantidade genérica para compatibilidade.
