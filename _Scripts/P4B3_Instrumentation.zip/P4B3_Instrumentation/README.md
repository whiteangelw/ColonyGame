# P4B.3 — Instrumentação de inicialização, save e load

Esta entrega mede os picos sem alterar algoritmos, formato do save ou ordem de restauração.

## Arquivos alterados

- `SaveGameService.cs`
- `WorldGenerator.cs`
- `TilemapVisualizer.cs`
- `FogOfWarManager.cs`
- `PerformanceMetricsService.cs`
- `DevModeManager.cs`

Os demais scripts enviados foram revisados e não precisam ser substituídos nesta fase.

## Marcadores no Unity Profiler

- `SaveGame.MenuSlotMetadata`
- `SaveGame.ReadFile`
- `SaveGame.DeserializeJson`
- `SaveGame.CaptureWorld`
- `SaveGame.SerializeJson`
- `SaveGame.WriteFile`
- `SaveGame.ClearRuntimeWorld`
- `SaveGame.RestoreGrid`
- `SaveGame.RestoreEntities`
- `SaveGame.PostRestore`
- `WorldGeneration.Generate`
- `TilemapVisualizer.FullRefresh`
- `FogOfWar.FullRefresh`

Marcadores existentes de NavGraph e LiquidVisualizer foram preservados.

## Hipótese já confirmada por revisão

`GameSessionMenuUI.RefreshSlotTexts()` chama `GetSlotDescription()` para cada slot. Atualmente `GetSlotDescription()` lê e desserializa o snapshot completo para obter somente `savedAtUtc`. No `Awake`, a atualização acontece em `SelectSlot(1)` e novamente em `OpenStartupMenu()`. Assim, um único save grande pode ser lido/desserializado duas vezes antes de o jogador escolher Continuar.

Esta entrega mede esse custo, mas ainda não muda o comportamento. A correção deve ser feita na P4B.4 depois de registrar os valores.

## Teste recomendado (Deep Profile desligado)

1. Use um save 500x500 no slot 1 e deixe os slots 2 e 3 vazios.
2. Abra Profiler > CPU Usage, limpe a captura e entre na cena.
3. No F1, fotografe `Menu metadata` e `Read / JSON load`.
4. Clique alternadamente nos slots 1, 2 e 3 e observe os marcadores.
5. Clique em Continuar e registre `Load`, `clear/grid/entities/post`, `Tilemap/Fog full`, NavGraph e Liquid full.
6. Salve e registre `Save`, `capture/json/write` e GC Alloc.
7. Repita com os três slots vazios para obter a linha de base.

## Como interpretar

- `Menu metadata` alto confirma desserialização indevida no menu.
- `Read` alto indica I/O; `JSON load` alto indica desserialização/objetos gerenciados.
- `Save capture` alto aponta para coleta do snapshot de 250.000 tiles/entidades.
- `Save json` alto aponta para `JsonUtility.ToJson` e a string grande.
- `Save write` alto aponta para escrita/cópia do backup.
- `Load grid` inclui a restauração do grid e notificações síncronas disparadas por `OnGridRebuilt`.
- `Tilemap/Fog full` separam dois consumidores globais do rebuild.

Não use os valores desta instrumentação como comparação final com build Release; use-os para ordenar os gargalos dentro do mesmo ambiente e cenário.
