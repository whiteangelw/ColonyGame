# Verificação temporal da jardinagem — v1.3c

Substitua:

- `CreatureDomestication.cs`
- `CreatureTerritorialGardener.cs`
- `CreatureGardeningRegistry.cs`
- `CreatureDebugPanel.cs`
- `PlanterStructureBehaviour.cs`

Não é necessário alterar prefabs ou ScriptableObjects.

## Interpretação da porcentagem

O valor representa aumento de velocidade:

- `0%` = `1.00x`;
- `25%` = `1.25x`;
- `100%` = `2.00x`.

Assim, uma planta de 60 segundos com bônus constante de 100% termina em
aproximadamente 30 segundos, não instantaneamente.

## Diagnóstico F2

O painel mostra a quantidade real de segundos removida pelo último pulso, o
tempo restante da última plantadeira afetada e o total de crescimento externo
aplicado no cultivo atual.

Com bônus de 100% e `Pulse Interval = 1`, o valor `Tempo removido no último
pulso` deve ficar próximo de `1.000s`. O tempo restante deve cair perto de dois
segundos por segundo real: um segundo natural e outro removido pela criatura.

Os contadores genéricos ficam na plantadeira e não conhecem criaturas; poderão
ser reutilizados futuramente por fertilizantes, clima ou máquinas.
