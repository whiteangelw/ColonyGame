# P5E.1 — Índice espacial e dirty flags

Esta etapa adiciona regiões como um **índice sobre o `GridData` atual**. Ela não
divide nem duplica os tiles, não faz streaming e não altera a simulação dos
duplicants.

## Arquivos

- `WorldRegionIndex.cs`: coordenadas, limites e estado sujo de cada região.
- `GridManager.cs`: cria o índice e marca regiões quando dados do grid mudam.
- `FogOfWarManager.cs`: marca Fog/Visual quando uma célula muda de estado.

Substitua os dois scripts existentes pelos arquivos deste pacote e adicione
`WorldRegionIndex.cs` à mesma pasta de scripts do projeto.

## Configuração inicial

`GridManager.regionSize` começa em **32**. Para esta etapa, mantenha esse valor
até termos medições comparáveis. O número de regiões esperado é:

| Mapa | Grade de regiões | Total |
|---|---:|---:|
| 100x90 | 4x3 | 12 |
| 250x250 | 8x8 | 64 |
| 500x500 | 16x16 | 256 |

As regiões da borda podem ser menores. Em 500x500, por exemplo, a última linha
e a última coluna têm 20 células de largura/altura.

## Dirty flags

| Alteração atual | Flags marcadas |
|---|---|
| Terrain/estrutura física | Terrain, Navigation, Liquid, Fog, Visual |
| BackWall/Decoration/conteúdo não físico | Visual |
| Quantidade de líquido | Liquid, Visual |
| Ocupação física | Navigation, Visual |
| Estado de fog | Fog, Visual |

Full generation e full load continuam usando `OnGridRebuilt`; ao concluir, as
flags acumuladas durante a reconstrução são limpas. Isso preserva o caminho
completo já testado.

## Diagnóstico manual

Durante Play Mode, abra o menu de contexto do componente `GridManager` e use
`P5E - Log Region Diagnostics`. O Console mostrará tamanho do mundo, tamanho da
região, grade, total e contagem suja por sistema.

1. Gere/carregue o mundo. As contagens devem começar em zero após o full rebuild.
2. Cave ou construa uma célula. Terrain/Navigation/Liquid/Fog/Visual devem ficar
   maiores que zero.
3. Altere apenas líquido. Liquid/Visual devem aumentar sem marcar Terrain.
4. Revele fog numa nova área. Fog/Visual devem aumentar.
5. Salve e carregue; confirme que o visual, NavGraph, fog e líquidos continuam
   iguais ao comportamento anterior.
6. Repita em 100x90, 250x250 e 500x500 e confirme os totais da tabela.

## Limite deliberado desta etapa

Tilemap, NavGraph, líquidos e fog **ainda não consomem regiões** para processar
atualizações parciais. Os eventos antigos continuam ativos. A migração de cada
sistema deve ocorrer separadamente nas próximas subfases do P5E, com profiling
entre elas. Culling visual também permanece separado da atividade de simulação.
