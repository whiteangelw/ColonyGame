# P5E.3 — Fog regional

Esta etapa preserva as regras atuais do fog e altera somente quando o cálculo é
solicitado e como as mudanças visuais são enviadas ao `FogTilemap`.

## Instalação

Substitua:

- `FogOfWarManager.cs`
- `DuplicantController.cs`
- `PerformanceMetricsService.cs`
- `DevModeManager.cs`

Os demais arquivos enviados foram analisados, mas não precisam ser substituídos.
Mantenha o `FogTilemap` com `Tilemap` e `TilemapRenderer` em `Mode = Chunk`.

## Configuração inicial

No `FogOfWarManager`, mantenha:

- `Maximum Dirty Cells Per Frame`: **2048**
- `Maximum Dirty Cells Per Region Pass`: **256**

## Mudanças

- O duplicant chama `RevealArea` ao entrar numa nova célula, não a cada frame.
- A distância circular usa comparação ao quadrado, sem `Mathf.Sqrt` por célula.
- O `FogState` muda imediatamente para manter a lógica do jogo correta.
- Somente células cujo estado realmente mudou entram na fila visual.
- Entradas repetidas são eliminadas.
- A fila é agrupada por região e processada em round-robin.
- Full refresh continua disponível para geração, load e debug.

## Métricas

O painel P4A passa a mostrar:

- `Fog regional avg/max`
- `Fog cells/pending`

Os três números de `cells/pending` são, respectivamente: células processadas no
intervalo, pico de células pendentes e pico de regiões pendentes.

No Profiler, procure por:

- `FogOfWar.RegionalRefreshBatch`
- `FogOfWar.FullRefresh`

## Testes manuais

1. Gere mundos 100x90, 250x250 e 500x500.
2. Deixe vários duplicants parados; o fog regional deve parar de trabalhar.
3. Mova um duplicant uma fração de tile; não deve ocorrer nova revelação.
4. Atravesse para outro tile; a área deve revelar normalmente.
5. Mova vários duplicants juntos e verifique se não aparece GC no marcador.
6. Teste perto das bordas do mapa e das divisões 31/32 e 63/64.
7. Desative e reative um duplicant; ele deve reavaliar sua célula uma vez.
8. Salve e carregue em uma área parcialmente explorada.
9. Confirme que o fog carregado é idêntico ao estado anterior.
10. Confirme que Tilemaps, água, tarefas, NavGraph e duplicants não mudaram.

## Preparação para iluminação futura

Não foi adicionada nenhuma regra de escuridão nesta etapa. Para a evolução
futura, mantenha três conceitos separados:

1. **Exploração persistente:** o que a colônia já descobriu e precisa ser salvo.
2. **Iluminação:** intensidade de luz atual, alterada por ambiente/equipamentos.
3. **Visibilidade:** resultado temporário de exploração + luz + alcance.

Assim, remover uma fonte de luz pode escurecer a área novamente sem apagar a
memória de que ela já foi explorada. Uma mudança de iluminação poderá solicitar
uma reavaliação mesmo com o personagem parado.
