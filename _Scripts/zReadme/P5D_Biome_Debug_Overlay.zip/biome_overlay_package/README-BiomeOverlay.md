# Overlay de diagnóstico de biomas

O overlay cria uma única textura com um pixel por célula. Em um mapa 500x500,
isso continua sendo apenas um `SpriteRenderer`, sem criar objetos por tile.

## Instalação

1. Adicione `BiomeDebugOverlay.cs` ao projeto.
2. Crie um GameObject vazio chamado `BiomeDebugOverlay`.
3. Adicione o componente `BiomeDebugOverlay` nele.
4. Marque `Visible On Start` ou pressione `F8` durante o jogo.
5. A lista `Colors` é opcional. Sem configuração, cada `biomeId` recebe uma
   cor determinística automaticamente.

Para definir cores próprias, adicione elementos em `Colors`, atribua o
`BiomeDefinitionSO` e escolha uma cor diferente para cada bioma.

## Comportamento

- Funciona apenas para mundos gerados nas versões 2 ou 3, que possuem
  `biomeId` no `WorldGenerationResult`.
- Saves carregados diretamente não possuem atualmente o mapa de biomas no
  formato de save; portanto, o overlay ficará vazio depois de iniciar pelo
  Load. Essa persistência será tratada na fase P5F.
- Não altera Tilemap, grid, NavGraph, Fog, líquidos, flora ou Save/Load.
- A legenda mostra somente os biomas encontrados no mundo atual.

## Testes

1. Gere um mundo novo com `Generation Version = 3`.
2. Pressione `F8` e confirme regiões contínuas, não ruído por tile.
3. Use a mesma seed e confirme o mesmo desenho de regiões.
4. Troque a seed e confirme um desenho diferente.
5. Teste 100x90, 250x250 e 500x500.
6. Ligue e desligue várias vezes e confirme que FPS, NavGraph e simulação não
   mudam significativamente.
