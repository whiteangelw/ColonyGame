# Status Strip de personagens — v1.1

Correção da v1.1: `DuplicantSelectionTarget` agora implementa a propriedade
`GridPosition` exigida por `IInteractable`.

Esta versão não altera `DuplicantController`, `DuplicantVitals`,
`LifeCycleSystem` ou `DevModeManager`.

## 1. Serviço central

No `GameManager` (ou em um filho chamado `SelectionServices`), adicione:

- `DuplicantSelectionService`

Deve existir somente um na cena.

## 2. Componentes do prefab

Na raiz do prefab de personagem, adicione:

- `DuplicantSelectionTarget`
- `DuplicantStatusStrip`

O personagem precisa manter seu Collider2D habilitado.

## 3. Hierarquia visual sugerida

Dentro do Canvas World Space já existente:

- `StatusStrip` (começa ativo; o script esconderá em runtime)
  - `EnergyBackground` (Image)
    - `EnergyFill` (Image)
  - `HungerBackground` (Image)
    - `HungerFill` (Image)

Configuração sugerida do `StatusStrip`:

- largura: 28
- altura total: 6
- posição Y: abaixo do nome e acima da cabeça
- cada barra: 28 x 2
- espaçamento vertical: 1

Em `EnergyFill` e `HungerFill`:

- Image Type: Filled
- Fill Method: Horizontal
- Fill Origin: Left
- Fill Amount: 1
- Raycast Target: desmarcado

Desmarque também `Raycast Target` do texto com o nome do personagem e das
imagens de fundo. A faixa é informativa, não interativa.

No componente `DuplicantStatusStrip`, atribua:

- Strip Root: `StatusStrip`
- Energy Fill: `EnergyFill`
- Hunger Fill: `HungerFill`

## 4. Comportamento

- Clique simples: seleciona um personagem e remove a seleção dos demais.
- Ctrl ou Shift + clique: adiciona/remove personagens da seleção.
- As faixas aparecem somente nos selecionados.
- Fome e energia são atualizadas pelo evento `OnVitalsChanged`, sem `Update()`.
- O F1 continua com sua seleção de diagnóstico independente.

## 5. Testes

1. Clique em um personagem: a faixa deve aparecer.
2. Clique em outro: a primeira deve sumir e a segunda aparecer.
3. Use Ctrl/Shift + clique: ambas devem permanecer visíveis.
4. Aguarde os ticks: os preenchimentos devem diminuir.
5. Alimente/descanse o personagem: a barra correspondente deve aumentar.
6. Abra o F1: a seleção de diagnóstico não deve alterar as faixas.
7. Clique no nome ou nas barras: o personagem ainda deve ser selecionável.
