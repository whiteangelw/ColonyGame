# Hotfix de caminho dinâmico v1.0d

Substitua somente `CreatureMovement.cs`.

O movimento agora escuta alterações do grid e valida cada transição do caminho.
Se um bloco for criado, removido ou o suporte deixar de existir:

1. a criatura interrompe o passo atual;
2. volta visualmente para a última célula confirmada;
3. registra a causa em `LastFailure`;
4. solicita uma nova decisão ao `CreatureBrain`;
5. o vínculo com habitat tenta calcular outro caminho;
6. o teleporte emergencial continua sendo usado apenas após o limite de falhas.

## Testes

1. Durante a viagem ao habitat, construa um bloco no caminho.
2. Confirme que a criatura para e procura outra rota, sem atravessá-lo.
3. Remova o bloco de suporte imediatamente à frente ou abaixo da criatura.
4. Confirme que ela interrompe o caminho antigo.
5. Feche novamente todas as rotas e confirme o fallback do habitat.
6. No F2, verifique `Última falha: Caminho alterado durante o movimento...`.

Não é necessário alterar o prefab nem adicionar componentes.
