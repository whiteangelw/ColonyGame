# Physical Structure Visual Fix v1.0

## Alteração

Substitua somente `TilemapVisualizer.cs`.

O visualizador deixa de desenhar os fallbacks legados de:

- `TileType.Chest`;
- `TileType.PrintingPod`.

Esses conteúdos possuem prefabs físicos restaurados pelo `StructureManager`.
Desenhar também o Tilemap criava duas imagens sobrepostas.

## Configuração confirmada do Chest_1

- Prefab: `Chest`;
- Requires Physical Prefab: habilitado;
- Requires Tile Asset: desabilitado;
- Tile Asset: vazio;
- Placement Layer: `Structure`.

Não altere essa configuração.

## Testes

1. Não mova o Transform da estrutura durante o Play Mode. A posição válida é
   controlada pelo grid e pelo footprint.
2. Carregue o mundo antigo e confirme que existe somente uma imagem do baú.
3. Construa um baú novo e confirme que existe somente o prefab físico.
4. Clique no centro e nas bordas do baú e da plantadeira.
5. Salve e carregue novamente.
6. Confirme que o inventário do baú continua preservado.
7. Confirme que o PrintingPod continua visível e funcional.

Se o prefab desaparecer junto com a cópia, confira se o `StructureManager`
possui os fallbacks legados configurados e se o save contém a estrutura. Em
construções modernas, o `BuildDefinitionSO` fornece o prefab diretamente.
