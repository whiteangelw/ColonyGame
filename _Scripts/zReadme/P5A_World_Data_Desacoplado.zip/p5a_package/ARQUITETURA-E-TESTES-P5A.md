# P5A — World Data e geração desacoplados

## Escopo entregue

Somente o P5A foi implementado. Não foram adicionados chunks, novos biomas,
flora procedural, formato novo de save, passes independentes ou RNG novo.

## Arquitetura anterior

`GridManager.GenerateGrid` criava o `GridData` e chamava
`WorldGenerator.GenerateWorld`. O `WorldGenerator` então escrevia célula por
célula no `GridManager`, alterava `Tile.fogState` e chamava `LiquidManager`.
Cada escrita atravessava APIs e eventos próprios do gameplay.

Responsabilidades acumuladas no `WorldGenerator`:

- configuração serializada;
- algoritmo de terreno, cavernas, minérios, lagos e superfície;
- mutação do grid de runtime;
- inicialização de fog;
- inicialização de líquido;
- cálculo e armazenamento do spawn.

## Arquitetura atual

Fluxo de criação de mundo novo:

1. `GridManager` cria o `GridData` vazio.
2. `WorldGenerator` transforma seus campos do Inspector em
   `WorldGenerationSettings`.
3. `LegacyWorldGeneration` executa exatamente a ordem atual dos passos.
4. O algoritmo devolve um `WorldGenerationResult`, sem tocar no runtime.
5. `GridData.ApplyGenerationResult` copia o snapshot em lote.
6. `GridManager` aplica as bordas de Bedrock e publica um único
   `OnGridRebuilt`.
7. Tilemap, Fog, líquido e NavGraph continuam reagindo pelos mecanismos atuais.

## Responsabilidades por camada

| Camada | Responsáveis no P5A |
| --- | --- |
| World/Grid Data | `WorldGenerationResult`, `WorldCellData`, `GridData`, `Tile` |
| Generation | `WorldGenerator`, `WorldGenerationSettings`, `LegacyWorldGeneration` |
| Presentation | `TilemapVisualizer`, `FogOfWarManager`, `LiquidVisualizer` |
| Runtime Simulation | `GridManager`, `LiquidManager`, `NavGraphGenerator`, interações e entidades |
| Persistência | `SaveGameService`, `SaveGameData` sem alteração |

## Arquivos alterados

- `WorldGenerator.cs`
- `GridManager.cs`
- `GridData.cs`
- `BiomePreset.cs`

## Arquivos novos

- `WorldBiomeLayer.cs`
- `WorldGenerationSettings.cs`
- `WorldGenerationResult.cs`
- `LegacyWorldGeneration.cs`

## Dependências removidas

- `WorldGenerator -> GridManager`
- `WorldGenerator -> LiquidManager`
- `WorldGenerator -> Tile` mutável
- `BiomePreset -> WorldGenerator.BiomeLayer`
- algoritmo de geração preso ao ciclo de vida do `MonoBehaviour`

## Compatibilidade preservada

- A ordem continua Terrain/Caves/Ores, Lakes, Spawn e Surface.
- Os cálculos Perlin e parâmetros continuam iguais.
- `CurrentSeed` e `GetSpawnPosition()` continuam disponíveis.
- O carregamento de save não passa pela geração e permanece igual.
- O evento final `OnGridRebuilt` continua inicializando os consumidores.
- O P5A mantém `UnityEngine.Random` para seed aleatória e posição dos lagos.
  Isso é intencional; a substituição pertence ao P5B.

## Riscos conhecidos

1. `WorldBiomeLayer` saiu de dentro do `WorldGenerator`. Os campos possuem os
   mesmos nomes e formato, mas confirme no Inspector se as listas do
   `WorldGenerator` e dos `WorldPreset` continuam preenchidas após recompilar.
2. A geração deixa de publicar milhares de `OnTileChanged` durante o bootstrap.
   Os sistemas enviados já escutam `OnGridRebuilt`, mas componentes externos
   devem usar esse evento para inicialização completa.
3. O snapshot de geração usa memória temporária proporcional ao mapa e é
   liberado após a aplicação. Isso evita acoplar o algoritmo ao grid; a memória
   deve ser medida no P5G antes de qualquer otimização mais complexa.

## Instalação

1. Faça commit ou backup do estado atual.
2. Substitua os quatro arquivos alterados pelos arquivos do pacote.
3. Adicione os quatro arquivos novos ao diretório de scripts do mundo.
4. Aguarde a recompilação do Unity.
5. Confira as referências de bioma no Inspector antes de entrar em Play Mode.

Não é necessário adicionar novos componentes ao GameObject nem configurar
campos novos.

## Testes manuais obrigatórios

### 1. Inspector

- Abra `WorldGenerator` e confirme suas camadas de bioma.
- Abra cada `WorldPreset` utilizado e confirme suas camadas.

### 2. Mundo novo

- Use os mesmos width/height e seed fixa do teste anterior.
- Confirme relevo, cavernas, minérios, lagos, superfície e área de spawn.
- Confirme as bordas de Bedrock.

### 3. Sistemas derivados

- Confirme que o Tilemap aparece completo.
- Confirme Fog inicial e revelação durante o jogo.
- Confirme que a água dos lagos aparece e continua simulando.
- Confirme que duplicants encontram caminhos e executam tarefas.

### 4. Save/Load

- Carregue um save anterior ao P5A.
- Crie um mundo novo, salve, volte ao menu e carregue.
- Compare tiles, fog, líquidos, flora, entidades e posição dos duplicants.

### 5. Escala

- Repita em `100x90` e `500x500`.
- Verifique Console e os marcadores de geração, Tilemap, Fog e NavGraph.

Não iniciar o P5B antes que esses testes estejam estáveis.
