# Correção de interação mundo/UI — v1.0

Substitua somente `BoxSelectionHandler.cs`.

## Causa

`EventSystem.current.IsPointerOverGameObject()` também considera resultados do
`Physics2DRaycaster`. Por isso, o BoxCollider2D de uma estrutura era tratado
como UI e o clique terminava antes da interação com o mundo.

## Correção

O handler agora bloqueia o clique apenas quando o resultado veio de um
`GraphicRaycaster`, ou seja, de uma UI gráfica verdadeira.

O `Physics2DRaycaster` e os `BoxCollider2D` podem permanecer habilitados.

## Testes recomendados

1. Reative o Physics 2D Raycaster da câmera.
2. Reative o BoxCollider2D do baú.
3. Clique no centro do baú, feche e abra novamente.
4. Repita com planteira e criatura.
5. Clique sobre botões e painéis: o mundo atrás deles não deve receber o clique.
6. Teste seleção em caixa e o menu de construção.
