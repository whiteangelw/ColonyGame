# Intent Messages v0.1

O sistema é independente da IA existente. Nenhum `Brain`, `TaskRunner`,
`Vitals`, `GameEvents` ou manager precisa ser substituído.

## Arquivos novos

- `DuplicantIntentModels.cs`
- `DuplicantIntentPhraseCatalogSO.cs`
- `DuplicantIntentSensor.cs`
- `DuplicantIntentPresenter.cs`

## Instalação

1. Coloque os quatro scripts em uma pasta de apresentação/feedback.
2. Crie o asset em:
   `Create > Duplicants > Intent Phrase Catalog`.
3. No prefab do personagem, adicione:
   - `DuplicantIntentSensor`;
   - `DuplicantIntentPresenter`.
4. Arraste o catálogo criado para `Phrase Catalog` no presenter.
5. O `FloatingTextManager` e seu prefab atual continuam sendo utilizados.

## Autonomia de configuração

No catálogo é possível:

- editar todas as frases sem alterar código;
- cadastrar várias frases para sorteio;
- alterar a cor de cada intenção;
- desligar categorias individualmente;
- permitir que avisos urgentes ignorem o cooldown;
- mudar o intervalo global entre mensagens;
- ajustar a altura do texto com `World Offset`.

Você também pode criar catálogos diferentes e atribuí-los a personagens
distintos. Isso permite testar estilos de fala diferentes antes de existir um
sistema completo de personalidade.

## Responsabilidades

- `DuplicantIntentSensor`: observa transições e emite uma intenção tipada;
- `DuplicantIntentPresenter`: decide se e quando deve apresentar;
- `DuplicantIntentPhraseCatalogSO`: contém somente dados editáveis;
- `FloatingTextManager`: continua cuidando apenas da pool e renderização.

## Testes

1. Atribua uma tarefa de cada tipo e confirme uma mensagem apenas na escolha.
2. Faça o personagem procurar comida, comer, buscar cama e dormir.
3. Baixe fome e energia atravessando seus limites.
4. Provoque uma tarefa inalcançável e verifique a mensagem de falha.
5. Coloque dois personagens trabalhando; cada um deve respeitar seu cooldown.
6. Desative uma categoria no catálogo e confirme que só ela deixa de aparecer.
7. Altere as frases durante o Play Mode para testar o tom rapidamente.

Mensagens são feedback narrativo, não estado de gameplay. Desativar o presenter
não altera nenhuma decisão, tarefa, reserva ou necessidade.
