# Visão geral persistente dos personagens — v1.0

Este pacote mantém seleção e visualização como conceitos separados.

## Comportamento

- clique simples: seleciona um personagem;
- Ctrl/Shift + clique: seleção múltipla;
- clique no mundo vazio: limpa a seleção;
- Esc: limpa a seleção;
- Tab: ativa/desativa a visão geral persistente;
- com a visão geral ativa, contornos e barras permanecem visíveis durante
  escavação, construção e outras ferramentas.

Tab não seleciona logicamente todos os personagens. Isso evita que futuras
ordens de grupo sejam aplicadas sem intenção.

## Arquivos

Substitua:

- `DuplicantSelectionService.cs`
- `BoxSelectionHandler.cs`
- `DuplicantSelectionOutline.cs`
- `DuplicantStatusStrip.cs`

`DuplicantSelectionTarget.cs` está incluído apenas para manter o pacote
completo; se a versão atual já funciona, não precisa substituí-la.

## Configuração

No `BoxSelectionHandler`, o campo `Overview Toggle Key` começa como `Tab`. A
tecla pode ser alterada no Inspector.

Não é necessário adicionar novos componentes ao prefab se o contorno e o
Status Strip já estiverem configurados.

## Testes

1. Selecione um personagem e confirme barra + contorno.
2. Ative Tab: todos devem mostrar barra + contorno.
3. Cave e construa: a visão geral deve permanecer.
4. Clique no vazio ou pressione Esc: a seleção é limpa, mas a visão geral
   continua ativa.
5. Pressione Tab novamente: apenas os selecionados devem permanecer visíveis.
6. Teste Ctrl/Shift + clique, baú, planteira, criatura e menus.
