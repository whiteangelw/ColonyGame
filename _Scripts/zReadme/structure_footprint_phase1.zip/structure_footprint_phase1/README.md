# Fase 1 — Footprint, posicionamento e navegação

Substitua os oito scripts existentes pelos arquivos da pasta `Scripts` e adicione `StructureFootprintSettings.cs` ao projeto.

## Configuração no Unity

1. Crie um GameObject vazio dentro do `GameManager` chamado `StructureFootprintSettings`.
2. Adicione o componente `StructureFootprintSettings`.
3. Em `Definitions`, adicione o PrintingPod:
   - Tile Type: `PrintingPod`
   - Width: `3`
   - Height: `3`
   - Origin Offset: `X = -1`, `Y = 0`
   - Blocks Movement: marcado
   - Supports Weight: marcado
   - Support Rule: `EveryBottomCell`
4. Adicione o baú:
   - Tile Type: `Chest`
   - Width: `1`
   - Height: `1`
   - Origin Offset: `0, 0`
   - Blocks Movement: marcado
   - Supports Weight: marcado
   - Support Rule: `EveryBottomCell`

Se o GameObject não for criado, o código usa exatamente esses valores como fallback.

`Origin Offset` informa onde começa o retângulo ocupado em relação à célula clicada. No PrintingPod 3×3, `(-1, 0)` significa uma célula à esquerda, a célula central clicada e uma célula à direita.

## Rigidbody e colliders

O `DuplicantMovement` configura automaticamente o `Rigidbody2D` do duplicant como `Kinematic`, porque o movimento é controlado pelo grid.

Para estruturas, o recomendado é:

- criar uma layer chamada `WorldInteractable`;
- colocar baús e máquinas nessa layer;
- usar `Collider2D` como `Is Trigger` quando ele servir apenas para clique;
- em `Project Settings > Physics 2D`, desativar colisão entre `Duplicant` e `WorldInteractable`.

Não remova o collider se ele for necessário para seleção. A layer e o grid devem decidir funções diferentes.

## Testes

1. Tente colocar o PrintingPod com uma das nove células dentro da terra.
2. Tente colocá-lo parcialmente fora do mapa.
3. Tente colocá-lo com apenas parte da base apoiada.
4. Construa-o e tente colocar um baú dentro do footprint.
5. Desmonte o PrintingPod clicando/selecionando qualquer célula de sua área.
6. Coloque comida no baú e confirme que o duplicant escolhe uma célula livre no perímetro.
7. Coloque um item no chão e construa uma escada na mesma célula.
8. Salve e carregue com PrintingPod, baú e blueprint ativos.

## Resultado esperado

- estruturas não atravessam terreno nem saem do mapa;
- footprints não se sobrepõem;
- estruturas com suporte obrigatório não flutuam;
- o NavGraph bloqueia a área física inteira da estrutura;
- tarefas procuram posições livres ao redor do footprint;
- itens no chão não bloqueiam a camada de construção;
- colliders não empurram o duplicant para fora da rota.

## Próxima fase

Criar o resolvedor de seleção por camadas e clique repetido: ferramenta ativa, estrutura/blueprint/flora/item e terreno.
