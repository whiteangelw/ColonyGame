# P5C — Biomas data-driven

Este pacote adiciona biomas configuráveis e regiões coerentes à versão 2 da
geração. A `generationVersion = 1` permanece usando exatamente o pipeline do
P5B. O P5C não cria entidades de flora, chunks ou um novo formato de save.

## Arquivos

Substitua os arquivos de mesmo nome:

- `WorldGenerator.cs`
- `WorldGenerationSettings.cs`
- `WorldGenerationContext.cs`
- `WorldGenerationResult.cs`
- `WorldGenerationPassFactory.cs`
- `DeterministicRandom.cs`

Adicione:

- `BiomeDefinitionSO.cs`
- `BiomeCatalogSO.cs`
- `BiomeGenerationPassesV2.cs`
- `Editor/P5CBiomeStarterAssets.cs` em uma pasta `Editor`

O pacote depende dos arquivos já instalados no P5B, especialmente
`WorldGenerationPipeline.cs`, `WorldGenerationPasses.cs`,
`WorldGenerationResult.cs` e `WorldGenerationBenchmark.cs`.

## Ativação segura

1. Faça backup ou commit do projeto.
2. Copie os arquivos e espere o Unity terminar a compilação.
3. Execute `Tools > World > P5C > Create Starter Biomes`.
4. Selecione o objeto com `WorldGenerator`.
5. Arraste `Assets/World/Biomes/P5C/StarterBiomeCatalog.asset` para
   `Biome Catalog`.
6. Mantenha `Generation Version = 1` para o teste de regressão.
7. Depois do teste, altere para `Generation Version = 2` para ativar o P5C.

## Arquitetura

- `BiomeDefinitionSO`: dados de um bioma; terreno, minérios, cavernas,
  profundidade, ambiente e referências futuras de flora/criaturas.
- `BiomeCatalogSO`: conjunto disponível e escala das regiões.
- `BiomeRegionPassV2`: produz o mapa de biomas por ruído climático contínuo.
- `WorldGenerationResult`: preserva o `biomeId` gerado para consumidores
  posteriores, sem alterar `GridData` ou o formato de save nesta fase.
- `BiomeTerrainPassV2`: escolhe terreno usando os pesos do bioma.
- `BiomeCavesPassV2`: usa parâmetros de cavernas do bioma.
- `BiomeOresPassV2`: aplica regras de minério do bioma.
- `BiomeSurfaceCoverPassV2`: aplica a cobertura superficial configurada.

Os passes conhecem o contrato de bioma; `WorldGenerator` somente recebe o
catálogo e seleciona a versão do pipeline. Não existem condicionais por id ou
tipo concreto de bioma no código.

## Compatibilidade

- Saves continuam armazenando o grid completo; nenhum formato foi alterado.
- Mundos novos na versão 1 devem continuar idênticos ao P5B para a mesma seed.
- A versão 2 é deliberadamente uma nova assinatura de geração.
- Flora e criaturas são apenas configuração futura; nada é instanciado.

## Testes manuais

### Regressão da versão 1

1. Use seed fixa e `Generation Version = 1`.
2. Gere 100x90, 250x250 e 500x500.
3. Compare hash, tilemap, spawn, NavGraph e métricas com o resultado do P5B.
4. Salve, carregue e confirme entidades, líquidos, fog e navegação.

### P5C versão 2

1. Use seed fixa, catálogo inicial e `Generation Version = 2`.
2. Gere duas vezes cada tamanho e confirme hashes iguais.
3. Verifique regiões amplas e coerentes, sem troca aleatória por tile.
4. Confirme presença dos três biomas conforme profundidade e clima.
5. Confirme que terreno, cavernas e minérios respeitam os assets.
6. Salve/carregue e confirme que o grid visual permanece igual.
7. Teste catálogo ausente: a geração deve falhar com erro explícito, sem
   selecionar bioma silenciosamente.

## Riscos conhecidos

- Alterar um asset de bioma muda mundos futuros da versão 2 mesmo mantendo a
  mesma seed. Antes de lançar saves baseados em seed, congele o conteúdo por
  `generationVersion` ou versione os catálogos.
- O mapa temporário de biomas guarda uma referência por célula durante a
  geração. Em 500x500 isso é aceitável nesta fase, mas deve ser medido no P5G.
- A divisão em regiões usa `Mathf.PerlinNoise`; a reprodutibilidade deve ser
  validada nos targets de build suportados antes de um save futuro por deltas.
