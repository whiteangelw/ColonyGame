# P5B — Pipeline determinístico

## Escopo

Esta entrega implementa somente o P5B sobre o P5A aprovado. Não adiciona
chunks, regiões, novos biomas, flora, POIs nem altera o formato do save.

## O que mudou

- A geração é executada por `WorldGenerationPipeline`.
- Cada etapa implementa `IWorldGenerationPass`.
- `WorldGenerationContext` concentra somente o estado temporário da execução.
- `DeterministicRandom` substitui `UnityEngine.Random` na geração.
- Cada pass recebe uma seed derivada de:
  `worldSeed + generationVersion + passId`.
- `generationVersion` foi adicionado ao `WorldGenerator`, às configurações e ao
  resultado da geração.
- Apenas a versão `1` está registrada. Versões desconhecidas são recusadas em
  vez de gerar um mundo silenciosamente incompatível.

## Ordem do pipeline versão 1

1. `BaseTerrainPass`
2. `SurfacePass` — ponto de extensão, sem conteúdo novo
3. `LayersPass`
4. `CavesPass`
5. `BiomesPass` — reservado ao P5C
6. `OresPass`
7. `SurfaceFeaturesPass` — lagos atuais
8. `FloraPass` — reservado ao P5D
9. `PointsOfInterestPass` — reservado para o futuro
10. `SpawnValidationPass`
11. `SurfaceCoverPass` — cobertura final atual

O pass final de cobertura permanece separado porque, no algoritmo aprovado,
grama/superfície são aplicadas depois dos lagos e da limpeza do spawn. Isso
preserva a ordem visual atual sem esconder essa regra dentro de outro pass.

## Determinismo

Com `Random Seed` desmarcado, os mesmos valores de seed, generationVersion,
dimensões e configurações produzem o mesmo mundo, inclusive os lagos.

Adicionar chamadas aleatórias ao futuro `FloraPass` não consome o fluxo de
`SurfaceFeaturesPass`; portanto, não desloca os lagos. O mesmo princípio vale
para os demais passes.

Os cálculos Perlin atuais de relevo, cavernas e minérios continuam usando a
seed original para preservar sua forma. O RNG derivado é usado pelas escolhas
discretas do pass e já está disponível para os próximos sistemas.

### Mudança esperada em relação ao P5A

Na primeira geração com o P5B, lagos de uma seed antiga podem aparecer em
outras posições, porque antes dependiam do estado global de
`UnityEngine.Random`. Depois do P5B, essas posições passam a ser repetíveis.
Relevo, cavernas e minérios mantêm os cálculos anteriores.

## generationVersion

- Use `1` no Inspector.
- Não aumente o número apenas por adicionar conteúdo configurável.
- Crie uma nova versão somente quando uma alteração precisar mudar o resultado
  produzido pela mesma seed.
- O save continua armazenando o grid completo; por isso seu formato não foi
  alterado no P5B. A persistência explícita da versão será tratada no P5F.

## Arquivos para substituir

- `WorldGenerator.cs`
- `WorldGenerationSettings.cs`
- `WorldGenerationResult.cs`
- `LegacyWorldGeneration.cs`

## Arquivos novos

- `DeterministicRandom.cs`
- `IWorldGenerationPass.cs`
- `WorldGenerationContext.cs`
- `WorldGenerationPipeline.cs`
- `WorldGenerationPassFactory.cs`
- `WorldGenerationPasses.cs`

Não altere os arquivos aprovados do P5A que não aparecem nesta lista.

## Testes obrigatórios

### Compilação e Inspector

1. Substitua os quatro arquivos e adicione os seis novos.
2. Confirme `Generation Version = 1` no `WorldGenerator`.
3. Confirme que as referências de preset e biomas continuam preenchidas.

### Determinismo com seed fixa

1. Desmarque `Random Seed`.
2. Escolha uma seed conhecida, por exemplo `1234`.
3. Gere um mundo e tire prints do relevo, lagos e spawn.
4. Saia do Play Mode e gere novamente sem alterar configurações.
5. Confirme que o mundo é idêntico.
6. Repita uma terceira vez.

### Seed diferente

1. Troque somente a seed.
2. Confirme que o mundo muda.
3. Volte para a seed anterior e confirme que o primeiro mundo retorna.

### Random Seed

1. Marque `Random Seed`.
2. Reinicie o Play Mode algumas vezes.
3. Confirme que novos mundos recebem seeds diferentes.

### Regressão

- Teste Tilemap, Fog, líquidos, NavGraph e spawn.
- Execute Dig, Build, Haul e Dismantle.
- Salve, volte ao menu e carregue.
- Carregue um save criado antes do P5B.
- Teste mapas `100x90` e `500x500`.
- Verifique o Console e o marcador `WorldGeneration.Generate`.

## O que não testar ainda

`BiomesPass`, `FloraPass` e `PointsOfInterestPass` não devem produzir conteúdo.
Eles existem apenas como contratos para fases futuras.

## Validação desta entrega

Os scripts receberam validação estrutural, conferência de dependências e teste
de integridade do pacote. A compilação completa depende do projeto Unity.
