# Jardineira Territorial v1.3

Substitua `CreatureDefinitionSO`, `CreatureController`,
`PlanterStructureBehaviour` e `CreatureDebugPanel`. Adicione os quatro scripts
novos do pacote.

## Separação de responsabilidades

Toda regra de espécie, domesticação, cuidado, habitat e distância está em
`CreatureTerritorialGardener`. A plantadeira contém somente um ponto genérico
para receber progresso externo e um registro de instâncias ativas. Ela não
referencia classes de criatura.

## Configuração

1. Crie `Create > Creatures > Abilities > Territorial Gardening`.
2. Configure inicialmente:
   - `Growth Speed Bonus Percent = 10`;
   - `Interaction Radius = 2`;
   - `Pulse Interval = 1`.
3. Atribua o asset em `Gardening Profile` no `CreatureDefinitionSO` da espécie.
4. Confirme que `CreatureTerritorialGardener` apareceu no prefab da criatura.

Espécies com `Gardening Profile` vazio não possuem a habilidade.

## Condições do bônus

- domesticada;
- vinculada ao habitat;
- cuidado do último ciclo satisfeito;
- criatura próxima da plantadeira;
- plantadeira dentro do território do habitat;
- cultivo atualmente crescendo.

Se várias criaturas alcançarem a mesma plantadeira, somente o maior bônus é
aplicado. Empates usam uma única criatura, portanto o efeito não acumula.

## Teste rápido

Use temporariamente uma planta com duração de `30` segundos. Compare sem a
criatura e depois com ela parada a até dois tiles da plantadeira. Com bônus de
10%, o tempo efetivo deve ficar próximo de `27,3` segundos.

O F2 mostra configuração, elegibilidade, última plantadeira, bônus e motivo.
