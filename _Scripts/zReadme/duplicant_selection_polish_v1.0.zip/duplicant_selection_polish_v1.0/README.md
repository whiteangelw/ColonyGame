# Polimento da seleção de personagens — v1.0

Inclui os quatro itens:

1. contorno no personagem selecionado;
2. clique no mundo vazio limpa a seleção;
3. Esc limpa toda a seleção;
4. Ctrl/Shift + clique mantém a seleção múltipla.

## Scripts

Substitua:

- `BoxSelectionHandler.cs`

Mantenha ou substitua pelas versões incluídas:

- `DuplicantSelectionService.cs`
- `DuplicantSelectionTarget.cs`

Adicione ao projeto:

- `DuplicantSelectionOutline.cs`

## Configuração do prefab

Na raiz do prefab do personagem, adicione `DuplicantSelectionOutline`.

No campo `Source Renderer`, arraste o `SpriteRenderer` do filho `Visual`.

Valores iniciais sugeridos:

- Outline Color: ciano claro
- Outline Width: `0.025`
- Sorting Order Offset: `1`

O script cria as cópias visuais somente em runtime. Não é necessário criar os
objetos de contorno manualmente no prefab.

## Regras de uso

- clique simples em personagem: seleção exclusiva;
- Ctrl/Shift + clique: adiciona ou remove da seleção;
- clique no mundo vazio: limpa a seleção;
- Esc: limpa a seleção;
- clicar em baú, planteira, máquina ou UI não é considerado mundo vazio.

## Testes

1. Selecione um personagem e confira contorno + Status Strip.
2. Selecione outro sem modificador: somente o segundo deve permanecer marcado.
3. Use Ctrl/Shift para selecionar dois personagens.
4. Clique novamente em um deles com Ctrl/Shift para removê-lo.
5. Clique no terreno vazio para limpar todos.
6. Pressione Esc para limpar todos.
7. Teste baú, planteira, criatura, menu de construção e seleção em caixa.
