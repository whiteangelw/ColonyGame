# Camadas de construção e ferramenta Cancelar

## Arquivos que devem ser substituídos

Substitua no projeto os arquivos `.cs` deste pacote pelos correspondentes. Não mantenha duas classes com o mesmo nome.

## Configuração das receitas

`BuildRecipe` agora possui `Placement Layer`:

- `Terrain`: blocos, escadas e construções antigas. É o padrão e mantém receitas existentes funcionando.
- `Structure`: alternativa semântica para máquinas e baús; continua sendo uma ocupação física.
- `BackWall`: parede de fundo. Não bloqueia movimento e pode coexistir com terreno, itens e estruturas.
- `Decoration`: decoração. Não bloqueia movimento e pode coexistir com as demais camadas.

No `BuildMenuUI`, abra cada elemento de `Build Recipes` e selecione a camada desejada. Para testar sem criar novos `TileType`, você pode cadastrar `Solid` como uma receita `BackWall` e outra receita `Decoration`; cada visualizador poderá usar um Tile Asset diferente para o mesmo tipo.

## Tilemaps no Unity

1. Dentro do mesmo `Grid` da cena, crie dois filhos: `BackWallTilemap` e `DecorationTilemap`.
2. Adicione `Tilemap` e `TilemapRenderer` aos dois objetos.
3. Adicione `TilemapVisualizer` em cada objeto.
4. No visualizador do primeiro, escolha `Visualized Layer = BackWall`.
5. No segundo, escolha `Visualized Layer = Decoration`.
6. Configure `Mapping List` com os `Tile Assets` usados pelas receitas.
7. No `TilemapRenderer`, deixe a parede atrás do terreno e a decoração à frente usando `Sorting Layer`/`Order in Layer`.

Sugestão de ordem visual: `BackWall = -10`, terreno atual `= 0`, decoração `= 5`, overlays/tarefas `= 10`.

## Cancelar

- Pressione `X` para entrar no modo `Cancel`.
- Clique ou arraste sobre uma área.
- Blueprints são cancelados, materiais já entregues são devolvidos pelo fluxo existente e suas tarefas desaparecem.
- Tarefas de cavar, transportar e outras tarefas pendentes também são removidas.
- Se um duplicante estiver executando a tarefa, seu runner é interrompido antes da remoção para limpar reservas e inventário com segurança.
- Estruturas já construídas não são desmontadas por `X`; use a ferramenta de desmontagem.

## Save

Paredes, decorações e a camada de cada blueprint são salvas. Saves antigos continuam aceitos: campos ausentes assumem `Terrain` ou `Empty`.

## Teste recomendado

1. Construa terreno e uma `BackWall` na mesma célula.
2. Adicione uma `Decoration` na mesma célula.
3. Confirme que o duplicante atravessa normalmente e que a navegação não é recalculada pela parede de fundo.
4. Crie dois blueprints na mesma célula, um em `BackWall` e outro em `Decoration`.
5. Pressione `X`, cancele cada projeto e confirme o reembolso.
6. Crie uma tarefa de cavar, espere um duplicante começar a andar e cancele com `X`.
7. Salve com parede, decoração e blueprint incompleto; carregue e confirme os três estados.

