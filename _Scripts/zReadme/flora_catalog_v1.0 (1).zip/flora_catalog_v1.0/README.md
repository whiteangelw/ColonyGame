# Flora Catalog v1.0

## Arquivos

- `FloraCatalogSO.cs`: novo catálogo central de floras.
- `FloraManager.cs`: substitui a versão atual.

Esta revisão mantém `GetDefinitionById`, usado pela plantadeira para restaurar
a espécie cultivada durante o carregamento do save.

## Configuração no Unity

1. Substitua apenas o `FloraManager.cs` atual.
2. Adicione `FloraCatalogSO.cs` ao projeto.
3. Aguarde o Unity compilar.
4. Crie o catálogo em `Create > Colony > Flora > Catalog`.
5. No campo `Definitions`, adicione cada `FloraDefinitionSO` uma única vez.
6. No objeto que contém `FloraManager`, arraste o catálogo para `Catalog`.
7. Mantenha `Dev Mode Definition` configurado como antes.

Não é necessário alterar `SaveGameService`, `SaveGameData`, prefabs ou as
definições de flora existentes.

## Validações

O catálogo avisa no Console quando encontra:

- uma posição vazia;
- `Flora Id` vazio;
- `Flora Id` duplicado;
- definição sem prefab.

## Teste recomendado

1. Inicie um mundo com Bush e todas as espécies de árvore.
2. Salve e carregue.
3. Confirme que todas retornaram.
4. Adicione temporariamente duas definições com o mesmo `Flora Id` e confirme
   que o aviso aparece no Console; depois corrija o ID.
