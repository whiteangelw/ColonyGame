# Interação P0 v1.0

Revisão 1.1: a detecção exata usa um raio vindo da câmera em vez de
`OverlapPointAll`. Assim, o centro do `BoxCollider2D` é reconhecido sem depender
do comportamento de consultas iniciadas dentro do collider.

Revisão 1.2: baús e estruturas configuradas usam seus registros no
`StructureManager` e testam diretamente os limites X/Y dos colliders. Esse é o
caminho determinístico para estruturas; raio e tolerância permanecem como
fallback para outros objetos interativos.

## Arquivos

- Substitua `BoxSelectionHandler.cs`.
- Adicione `WorldClickInteractionResolver.cs`.
- Não altere `WorldInteractionService`, `IInteractable`, o baú ou a plantadeira.

## Inspector

No objeto que contém `BoxSelectionHandler`:

- `Interaction Tolerance In Cells`: comece com `0.55`.
- `Log Interaction Diagnostics`: habilite durante os testes.

Uma tolerância muito alta pode selecionar uma estrutura vizinha. Recomenda-se
manter o valor entre `0.35` e `0.65`.

## Hierarquia obrigatória das UIs

O GameObject que contém `ChestInspectUI` precisa começar **ativo**. Somente seu
filho `Panel Container` deve ficar desativado.

Use a mesma regra para `PlanterInspectUI`:

```text
UI_Manager (ativo)
├── ChestInspectUI (script, ativo)
│   └── ChestPanel (Panel Container, começa desativado)
└── PlanterInspectUI (script, ativo)
    └── PlanterPanel (Panel Container, começa desativado)
```

Se o próprio objeto com o script começar desativado, `Awake` não inicializa o
singleton e a estrutura não encontra a UI.

## Colliders

Cada prefab interativo ainda deve ter pelo menos um `Collider2D`. Ajuste-o para
cobrir a parte visual clicável, sem incluir áreas vazias muito grandes. A
tolerância é apenas uma margem de conforto, não substitui um collider correto.

## Testes

1. Clique no centro e nas bordas do baú.
2. Clique na base e na parte visível superior da plantadeira.
3. Feche e reabra os dois painéis três vezes.
4. Coloque baú e plantadeira lado a lado e confirme que o alvo correto abre.
5. Clique em terreno vazio e confirme que nenhuma UI abre.
6. Teste os modos `Dig`, `Build`, `Haul`, `Harvest`, `Dismantle` e `Cancel`.
7. Desative os diagnósticos depois que os testes passarem.

No Console, um clique dentro do collider de uma estrutura deve aparecer como
`bounds registrados/baú` ou `bounds registrados/estrutura`. A mensagem
`tolerância` deve ficar restrita à pequena margem externa.

Há duas cópias idênticas de `WorldInteractionService` entre os arquivos
enviados. Mantenha somente um arquivo com essa classe no projeto.
