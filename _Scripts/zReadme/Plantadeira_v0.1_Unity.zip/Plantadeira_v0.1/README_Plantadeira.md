# Plantadeira v0.1

## O que esta versão faz

- Começa o cultivo assim que a estrutura é construída.
- Cresce durante um tempo configurável.
- Quando pronta, pode receber a ordem `Harvest` com a tecla `H`.
- A colheita usa o fluxo atual: alimento no chão → transporte → baú → refeição.
- Replanta automaticamente depois que todas as porções forem colhidas.
- Salva e restaura os estados `Empty`, `Growing` e `Ready`, incluindo o tempo restante.

Não há semente, irrigação ou tarefa separada de plantio nesta v0.1. Isso mantém o protótipo pequeno e valida primeiro o loop renovável de comida.

## Arquivos

- `PlanterSettingsSO.cs`: somente configuração editável no Inspector.
- `PlanterStructureBehaviour.cs`: ciclo de crescimento da estrutura.
- `PlanterCrop.cs`: alvo compatível com o `HarvestTaskHandler` existente.
- `FloraManager.cs`: versão do Harvest v0.1 com registro separado para cultivos de estruturas.
- `SaveGameData.cs`: versão atual com os campos de persistência da Plantadeira.
- `SaveGameService.cs`: versão atual com captura e restauração da Plantadeira.

## Configuração no Unity

1. Substitua `SaveGameData.cs`, `SaveGameService.cs` e `FloraManager.cs` pelas versões deste pacote.
2. Adicione os três scripts novos ao projeto.
3. Crie um asset em `Create > Colony > Structures > Planter Settings`.
4. Em `Crop Definition`, use o mesmo `FloraDefinitionSO` da `WildBerry` já testada.
5. Configure `Growth Duration`, sprites provisórios e tamanho da área clicável.
6. No prefab da Plantadeira, mantenha `ConfiguredStructure` no objeto raiz.
7. Adicione `PlanterStructureBehaviour` ao mesmo objeto e atribua o asset de settings.
8. Crie/ajuste um `BuildDefinitionSO` para a Plantadeira:
   - `Prefab`: prefab acima;
   - `Requires Physical Prefab`: ligado;
   - `Placement Layer`: `Structure`;
   - footprint com apoio inferior e passagem conforme o visual desejado.
9. Adicione esse `BuildDefinitionSO` ao catálogo de construções já usado pelo jogo.

## Testes mínimos

1. Construir: o sprite de crescimento deve aparecer.
2. Esperar: ao terminar o tempo, deve trocar para o sprite pronto.
3. Selecionar com `H`: deve criar a tarefa de colheita existente.
4. Colher: deve surgir o recurso configurado no chão.
5. Novo ciclo: deve voltar ao estado de crescimento.
6. Salvar crescendo e carregar: deve continuar com o tempo restante.
7. Salvar pronta e carregar: deve continuar pronta para colher.
8. Desmontar: a Plantadeira e seu cultivo filho devem desaparecer sem flora órfã.

## Erro comum

Se a ordem `H` não selecionar o cultivo, confirme que o sprite/collider aparece sobre a Plantadeira e que `Crop Definition` não está vazio. O collider é criado automaticamente pelo comportamento.
