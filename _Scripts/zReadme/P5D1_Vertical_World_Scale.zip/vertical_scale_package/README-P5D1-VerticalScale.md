# P5D.1 — Escala vertical do mundo

Esta correção adiciona `Generation Version = 4`. As versões 1, 2 e 3 mantêm
o cálculo anterior baseado em `Surface Height` fixo.

Na versão 4, a superfície é calculada como proporção da altura do mapa. O
valor padrão de `0.70` posiciona a superfície em aproximadamente 70% da altura,
deixando 30% para céu e cerca de 70% para terreno subterrâneo.

## Arquivos para substituir

- `WorldGenerator.cs`
- `WorldGenerationSettings.cs`
- `WorldGenerationPasses.cs`
- `WorldGenerationPassFactory.cs`

## Configuração recomendada

- `Generation Version`: `4`
- `Relative Surface Height`: `0.70`
- `Minimum Sky Height`: `20`
- `Minimum Terrain Depth`: `30`
- `Height Variation`: `8` a `20`

O sistema sempre reserva espaço para o céu e para a variação do relevo. Em um
mapa 500x500 com proporção 0.70, a superfície-base ficará perto de `y = 349`,
criando profundidade suficiente para o `RockyDepths`.

## Fundamento

`Map Height` define a altura total do grid. Ele não deve ser confundido com a
profundidade do terreno. Até a versão 3, aumentar o mapa para 500 mantinha a
superfície em 50; portanto, quase todo o espaço adicional virava céu vazio.

## Testes

1. Confirme que as versões 1–3 continuam gerando seus resultados anteriores.
2. Gere versão 4 em 100x90, 250x250 e 500x500.
3. Use o overlay e confirme a presença das três regiões de bioma.
4. Na mesma seed e configuração, gere duas vezes e compare o overlay/hash.
5. Confirme que o spawn fica acima da superfície e livre de flora/líquido.
6. Salve e carregue verificando grid, flora, duplicants, Fog e NavGraph.
7. Em 500x500, confirme que apenas as bordas continuam sendo Bedrock.

Alterar a proporção, altura mínima do céu ou profundidade mínima muda o mundo
gerado. Depois de escolher os valores definitivos, trate-os como parte da
configuração da versão 4.
