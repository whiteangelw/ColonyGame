# Visitas de jardinagem — v1.4

## Substitua

- `CreatureBrain.cs`
- `CreatureGardeningProfileSO.cs`
- `CreatureTerritorialGardener.cs`
- `CreatureGardeningRegistry.cs`
- `PlanterStructureBehaviour.cs`
- `CreatureDebugPanel.cs`
- `CreatureDomestication.cs`

`CreatureMovement.cs` e `CreatureController.cs` foram analisados, mas não
precisam ser substituídos. Nenhum componente novo precisa ser colocado nos
prefabs.

## Configuração recomendada

- `Growth Speed Bonus Percent`: `10`
- `Interaction Radius`: `8`
- `Interaction Distance`: `1`
- `Tending Duration`: `2`
- `Bonus Duration`: `30`
- `Effect Pulse Interval`: `1`
- `Maximum Visits Per Round`: `4`
- `Gardening Round Cooldown`: `20`
- `Failed Target Cooldown`: `10`

## Regra

A criatura não concede mais bônus apenas por proximidade. Ela procura uma
plantadeira crescendo dentro do raio medido a partir do centro do habitat,
valida uma posição de interação e um caminho completo, reserva o alvo, caminha
até ele, permanece cuidando e só então aplica o efeito temporário.

Plantadeiras prontas, vazias, já beneficiadas, reservadas ou inalcançáveis são
ignoradas. Alvos sem caminho entram em cooldown e não prendem a criatura.

O deslocamento continua sendo feito exclusivamente pelo `CreatureMovement`
atual. Mudanças no grid durante a caminhada invalidam o passo; a visita é
cancelada e a criatura volta ao Brain normal sem teleporte.

## Testes

1. Planta acessível: deve ocorrer `Travelling -> Tending -> bônus`.
2. Parede antes da escolha: a planta deve aparecer como inalcançável.
3. Parede durante a caminhada: o movimento e a visita devem ser cancelados.
4. Remover o chão durante a caminhada: não deve atravessar nem continuar
   cegamente.
5. Duas criaturas: não devem escolher simultaneamente a mesma plantadeira.
6. Planta pronta durante a visita: a visita deve ser abandonada.
7. Várias plantas: a criatura deve visitá-las sequencialmente até o máximo da
   rodada e depois voltar ao patrulhamento.

O efeito curto não é persistido no save. Ao carregar, a criatura poderá visitar
novamente a planta; nenhum progresso já aplicado é revertido.
