# Fundação de habitat v1.0b

Esta etapa cria somente os dados e o registro de habitats. Criaturas ainda não
são vinculadas e seu comportamento ainda não muda.

## Scripts novos

- `CreatureHabitatSettingsSO.cs`;
- `CreatureHabitatRegistry.cs`;
- `CreatureHabitatBehaviour.cs`.

Nenhum script atual precisa ser substituído nesta etapa.

## Criar a configuração

1. No Project, use `Create > Creatures > Habitat Settings`.
2. Configure:
   - `Display Name`;
   - `Capacity = 1` para o primeiro teste;
   - `Compatible Species`: arraste os `CreatureDefinitionSO` permitidos;
   - `Patrol Center Offset`: normalmente `(0, 1)`;
   - `Patrol Radius`: comece com `5`.

A lista de espécies é explícita. Se estiver vazia, nenhuma criatura pode usar o
habitat. Isso impede que criaturas futuras entrem automaticamente nesse sistema.

## Configurar o prefab físico

Na raiz do prefab do habitat, adicione:

- `ConfiguredStructure`;
- `CreatureHabitatBehaviour`;
- o collider e a apresentação visual que a estrutura já utiliza.

No `CreatureHabitatBehaviour`, atribua o asset em `Settings`.

No `BuildDefinitionSO` do habitat:

- atribua esse prefab em `Prefab`;
- habilite `Requires Physical Prefab`;
- use `Placement Layer = Structure`;
- configure footprint, custo, recurso e tempo normalmente;
- adicione a definição ao `BuildCatalogSO`.

Não é necessário adicionar nada ao prefab da criatura nesta etapa.

## Teste

1. Construa o habitat.
2. Durante o Play Mode, selecione a instância construída.
3. O campo `Runtime Status` deve mostrar `Registrado`, ocupação `0/1` e o centro.
4. No menu de contexto do componente, execute `Log Habitat State`.
5. O Console deve indicar pelo menos um habitat registrado.
6. Desmonte a estrutura e confirme que ela desaparece sem erros.
7. Selecione o prefab no Scene View para visualizar o raio do território.

Save/Load da própria construção já funciona pelo fluxo existente de
`ConfiguredStructure`. Ocupantes e vínculos serão persistidos na próxima etapa.
