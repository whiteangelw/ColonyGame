# Construções por camada + Plantadeira v0.2

## Objetivo

Este pacote separa definitivamente os dados de `Terrain`, `Structure`, `BackWall` e `Decoration`.
`TileType` continua sendo uma classificação física genérica; a identidade visual e persistente vem de `definitionId/contentId`.

Também adiciona uma UI exclusiva da Plantadeira. Nenhum código ou evento de `ChestInspectUI` foi reutilizado.

## Arquivos substituídos

- `Tile.cs`
- `GridData.cs`
- `GridManager.cs`
- `SaveGameData.cs`
- `SaveGameService.cs`
- `StructureManager.cs`
- `BoxSelectionHandler.cs`
- `FloraManager.cs`
- `PlanterSettingsSO.cs`
- `PlanterStructureBehaviour.cs`
- `PlanterCrop.cs`

## Arquivo novo

- `PlanterInspectUI.cs`

## Configuração das camadas

Use no `BuildDefinitionSO`:

- blocos físicos: `Placement Layer = Terrain`;
- cama, Plantadeira e máquinas: `Placement Layer = Structure`;
- paredes de fundo: `Placement Layer = BackWall`;
- objetos decorativos: `Placement Layer = Decoration`.

Cada definição precisa de um `Definition Id` único. Não adicione cama e Plantadeira como fallbacks do mesmo `TileType.Structure`. O fallback é apenas para conteúdo legado sem definição.

Estruturas com prefab físico desenham o próprio visual. Nesse caso, o `TilemapVisualizer` não desenha também o `Tile Asset` por baixo.

## Configuração da UI da Plantadeira

1. Crie um painel próprio no Canvas chamado `PlanterPanel`.
2. Adicione `PlanterInspectUI` a um objeto exclusivo, por exemplo `PlanterInspectUI`.
3. Ligue `Panel Container`, `Title Text`, `Status Text`, `Crop Options Root`, `Crop Option Button Prefab` e `Close Button`.
4. O prefab do botão precisa ter `Button` e um texto `TextMeshProUGUI` filho.
5. No `PlanterSettingsSO`, preencha `Available Crops` com as `FloraDefinitionSO` permitidas.
6. Com `Start Planted` desligado, clicar na Plantadeira abre o painel e permite escolher uma planta.

## Testes recomendados

1. Construa uma cama e uma Plantadeira: nenhuma deve desenhar o visual da outra.
2. Confirme que o terreno sob ambas permanece inalterado.
3. Coloque backwall e decoração na mesma coordenada de uma estrutura.
4. Salve e carregue as quatro camadas.
5. Construa a Plantadeira com `Start Planted` desligado, clique nela e escolha uma planta.
6. Salve durante o crescimento e confira a espécie e o tempo após carregar.
7. Clique no baú: somente `ChestInspectUI` deve abrir.
8. Clique na Plantadeira: somente `PlanterInspectUI` deve abrir.

## Compatibilidade

Saves antigos sem `structureTileTypes` continuam sendo lidos. O tipo da estrutura é inferido pelo `structureContentId` e pelo catálogo de construções.
