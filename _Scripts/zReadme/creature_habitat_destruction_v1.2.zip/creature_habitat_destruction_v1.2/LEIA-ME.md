# Destruição segura de habitat v1.2

Substitua os seis scripts incluídos. Não altere prefabs.

## Nova regra

Cada criatura passa a manter duas referências:

- `NaturalHomePosition`: território original, que não muda ao ganhar habitat;
- `HomePosition`: território usado atualmente pelo comportamento.

Quando o habitat é removido ou desativado:

1. todos os ocupantes são notificados imediatamente;
2. o movimento atual até o habitat é cancelado;
3. a vaga é liberada;
4. `HomePosition` volta para `NaturalHomePosition`;
5. a criatura permanece domesticada;
6. o cérebro procura outro habitat compatível na próxima decisão;
7. sem outro habitat, ela patrulha o território natural.

O save agora guarda a casa natural separadamente. Saves anteriores continuam
carregando; quando não existe esse campo, a posição atual da criatura é usada
como fallback seguro caso ela estivesse vinculada.

## Testes

1. Destrua o habitat enquanto a criatura está caminhando até ele.
2. Confirme que ela interrompe o movimento imediatamente.
3. Sem outro habitat, confira no F2 que `Casa` voltou para `Casa natural`.
4. Construa dois habitats compatíveis e destrua o ocupado.
5. Confirme que a criatura reserva o outro e caminha até ele.
6. Salve e carregue vinculada; destrua a estrutura e confirme a casa natural.
7. Verifique que domesticação e cuidado diário não foram perdidos.
