# P5E.2 — Atualização visual agrupada por região

Esta etapa altera apenas a apresentação dos Tilemaps atendidos por
`TilemapVisualizer`. Geração, save/load, NavGraph, fog, líquidos, tarefas e
simulação continuam com o comportamento atual.

## Instalação

Substitua:

- `TilemapVisualizer.cs`
- `PerformanceMetricsService.cs`
- `DevModeManager.cs`

`GridManager.cs` e `WorldRegionIndex.cs` do P5E.1 permanecem sem alteração.

Não adicione `TilemapVisualizer` ao `WaterTilemap`: ele já é controlado pelo
`LiquidVisualizer`. Também não adicione ao `FogTilemap` ou
`TaskOverlayTilemap`, pois eles possuem caminhos próprios.

## Configuração

Mantenha todos os `TilemapRenderer` em `Mode = Chunk`.

Cada `TilemapVisualizer` passa a mostrar:

- `Maximum Dirty Cells Per Frame`: limite total daquele Tilemap por frame.
  Comece com **2048**.
- `Maximum Dirty Cells Per Region Pass`: quantidade processada numa região
  antes de dar oportunidade às outras. Comece com **256**.

Esses valores são independentes do `Region Size = 32` do GridManager. Uma
região organiza a fila, mas somente células realmente modificadas são
redesenhadas.

## Como funciona

1. Um evento informa que uma célula visual mudou.
2. O visualizador encontra a região dessa célula.
3. A célula entra na fila particular daquele Tilemap.
4. Repetições da mesma célula são descartadas enquanto estiverem pendentes.
5. No `LateUpdate`, as regiões são atendidas em round-robin dentro do orçamento.

Terrain, BackWall, Decoration e Background mantêm filas independentes. Nenhum
visualizador limpa o trabalho pendente de outro.

## Background

O objeto `Background` pode continuar como está nesta etapa. Se futuramente ele
for apenas uma imagem decorativa por bioma, o melhor desenho provavelmente será
um sistema próprio de background regional, em vez de representar uma imagem
grande como milhares de tiles. Essa decisão não precisa ser tomada agora.

## Métricas novas

O painel P4A passa a mostrar:

- `Tilemap regional avg/max`: custo médio e maior custo dos lotes.
- `Tilemap regional cells`: células processadas no intervalo.
- `Tilemap pending peak`: maior fila observada em células e regiões.

No Unity Profiler, procure por:

- `TilemapVisualizer.RegionalRefreshBatch`
- `TilemapVisualizer.FullRefresh`

## Testes manuais

1. Gere mundos 100x90, 250x250 e 500x500.
2. Confirme que Terrain, BackWall, Decoration e Background continuam idênticos.
3. Cave e construa uma única célula; a mudança deve aparecer até o fim do frame.
4. Marque uma área grande para escavação e observe as novas métricas.
5. Construa/remova conteúdo de BackWall e Decoration.
6. Teste células próximas às divisões 31/32, 63/64 e às bordas do mapa.
7. Salve e carregue; nenhuma célula antiga deve permanecer desenhada.
8. Confirme que água, fog e task overlay continuam funcionando normalmente.
9. Compare `GC Alloc` antes/depois após alguns segundos de aquecimento.

## Resultado esperado

- Mudança isolada: 1 célula processada por Tilemap relevante.
- Muitas mudanças repetidas na mesma célula: 1 entrada pendente.
- Alterações em regiões diferentes: todas avançam sem uma região monopolizar a
  fila.
- Geração/load: continuam usando full refresh.
